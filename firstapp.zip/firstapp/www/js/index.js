function calculate(){
  var f = document.getElementById("from").value;
  var t = document.getElementById("to").value;
  var p = document.getElementById("pool").value;
  var d = document.getElementById("direct").value;

  var TotalPrice=0;
  var basefare=2.5;
  var servicefees=1.75;
// read the date and count the fare
  if(f== "275 Yorkland Blvd" && t="CN Tower"){
     TotalPrice= basefare + servicefees + (22.9)*(0.81);
  }else if(f== "Fairview Mall" && t="Tim Hortons"){
    TotalPrice= basefare + servicefees + (1.2)*(0.81);
  }

// counting the minimum Fair
var minFare=5.50;
if(TotalPrice> minFare){

  TotalPrice = minFare;

}else{
  TotalPrice = TotalPrice;
}

// calculation for Adding the Price

if (pool.checked){
    TotalPrice = TotalPrice;
}else if (direct.checked) {
    TotalPrice = (TotalPrice) * 0.10 + TotalPrice;
  }
  document.getElementById("Ride").innerHTML =   "Total Price: " + TotalPrice + "<br>"
}
